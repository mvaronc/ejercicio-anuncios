<?php

if(isset($_POST['install'])){
//Datos que llegan del formulario de instalación de la base de datos
$host=$_POST['host'];
$user=$_POST['user'];
$passDB=$_POST['passDB'];
$nameDB=$_POST['nameDB'];
$portDB=$_POST['portDB'];
$conexion=mysqli_connect($host,$user,$passDB,$nameDB,$portDB);
if($conexion===false){
    echo "Error al conectar con la base de datos<br> Verifica los datos de conexión<br>";
    echo mysqli_connect_error();
}else{
    $contenidoArchivoConfig="<?php
    define('DB_HOST','$host');
    define('DB_USER','$user');
    define('DB_PASS','$passDB');
    define('DB_NAME','$nameDB');
    define('DB_PORT','$portDB');
    ?>";
    $fp=fopen("../config/config.php","w");
    if($fp===false){
        echo "Error al crear el archivo de configuración<br>";
    }else{
       fwrite($fp,$contenidoArchivoConfig);
        fclose($fp);
        echo "Archivo de configuración creado con éxito<br>";
    
        $consultas[]="CREATE TABLE `users` (`login` VARCHAR(50) NOT NULL , `name` VARCHAR(100) NOT NULL , `surname1` VARCHAR(100) NOT NULL , `surname2` VARCHAR(100) NULL , `email` VARCHAR(100) NOT NULL , `password` VARCHAR(512) NOT NULL , `rol` ENUM('admin','registrado') NOT NULL , `activo` BOOLEAN NOT NULL , PRIMARY KEY (`login`), UNIQUE (`email`)) ENGINE = InnoDB; ";

        $consultas[]="CREATE TABLE `posts` (
            `id` BIGINT NOT NULL AUTO_INCREMENT ,
            `description` TEXT NOT NULL ,
            `date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ,
            `active` BOOLEAN NOT NULL DEFAULT FALSE ,
            `login` VARCHAR(50) NOT NULL ,
            PRIMARY KEY (`id`),
            Foreign Key (`login`) REFERENCES users(`login`)
            on delete cascade on update cascade
            ) ENGINE = InnoDB; ";

        //Datos que llegan del formulario de instalación del primer usuario
        $loginAdmin=$_POST['login'];
        $nameAdmin=$_POST['name'];
        $surname1Admin=$_POST['surname1'];
        $mailAdmin=$_POST['mail'];
        $passAdmin=password_hash($_POST['pass'], PASSWORD_DEFAULT);
        $consultas[]="INSERT INTO `users` (`login`, `name`, `surname1`, `surname2`, `email`, `password`, `rol`, `activo`) VALUES 
        ('$loginAdmin', '$nameAdmin', '$surname1Admin', NULL,'$mailAdmin', '$passAdmin', 'admin', '1') ";

        while($consulta=array_shift($consultas)){
             $resultado=$conexion->query($consulta);
                if($resultado===false){
                    echo "Error en la consulta: $consulta<br>";
                    echo $conexion->error."<br>";
                    break;
                }else{
                    echo "Consulta <br/>$consulta<br/>
                        realizada con éxito<br>";
                }
        }
        $conexion->close();
        echo "Instalación finalizada con éxito<br>";    
        }
    }
    }//Fin del if que comprueba si se ha pulsado el botón de instalación




?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalación de anuncios</title>
    <link rel="stylesheet" href="../css/estilos.css">

</head>
<body>
    <h1>Instalación de la aplicación de anuncios</h1>
    <form action="install.php" method="post">
        <h2>Base de datos</h2>
        <label for="host">Servidor de base de datos</label>
        <input type="text" name="host" id="host" required>
        <label for="user">Usuario de la base de datos</label>
        <input type="text" name="user" id="user" required>
        <label for="passDB">Contraseña de la base de datos</label>
        <input type="password" name="passDB" id="passDB" required>
        <label for="nameDB">Nombre de la base de datos</label>
        <input type="text" name="nameDB" id="nameDB" required>
        <label for="portDB">Puerto de la base de datos</label>
        <input type="number" name="portDB" id="portDB" required>

        <h2>Administrador de la aplicación</h2>
        <label for="login">Login del administrador</label>
        <input type="text" name="login" id="login" required>
        <label for="name">Nombre del administrador</label>
        <input type="text" name="name" id="name" required>
        <label for="surname1">Primer apellido del administrador</label>
        <input type="text" name="surname1" id="surname1" required>
        <label for="mail">Correo electrónico del administrador</label>
        <input type="email" name="mail" id="mail" required>
        <label for="pass">Contraseña del administrador</label>
        <input type="password" name="pass" id="pass" required>
        <input type="submit" name="install" value="Instalar">
    </form>
    
</body>
</html>